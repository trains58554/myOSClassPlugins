<?php

/**
 * The base MySQL settings of OSClass
 */
define('MULTISITE', 0);

/** MySQL database name for OSClass */
define('DB_NAME', 'a8440393_openCla');

/** MySQL database username */
define('DB_USER', 'a8440393_openUse');

/** MySQL database password */
define('DB_PASSWORD', 'wood4life');

/** MySQL hostname */
define('DB_HOST', 'mysql8.000webhost.com');

/** Database Table prefix */
define('DB_TABLE_PREFIX', 'oc_2');

define('REL_WEB_URL', '/public_html/sf/');

define('WEB_PATH', 'http://sf.sfads.netne.net/');

?>
